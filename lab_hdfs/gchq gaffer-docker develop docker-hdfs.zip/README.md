
```
docker-compose up
```

Access the HDFS NameNode web UI at: http://localhost:9870
